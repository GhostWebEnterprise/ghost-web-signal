# GhostWeb Signal — Liquid Glass Design System
**Version 2.0 · Photon Edition**

---

## 1. Brand Overview

**GhostWeb Signal** is a privacy-first messaging app built on the Signal protocol.  
The new **Liquid Glass Photon** visual language combines:

- Deep navy / ice-blue dark theme (Photon)
- Soft, translucent **Liquid Glass** surfaces
- Clean Signal-inspired information architecture
- Modern tech aesthetic with high legibility

**Tagline:** Secure. Private. Untraceable.

---

## 2. Color System

### 2.1 Core Palette — Dark Mode (Default)

| Token                        | Hex / Value          | Usage                              |
|-----------------------------|----------------------|------------------------------------|
| `bg`                        | `#050914`            | App background                     |
| `surface / panel`           | `#0D1A33`            | Cards, headers, bottom sheets      |
| `surface_high`              | `#132445`            | Elevated surfaces                  |
| `surface_low`               | `#08101F`            | Recessed areas                     |
| `primary / cyan`            | `#5B9DFF`            | Primary actions, unread, accents   |
| `primary_dim`               | `#7EB6FF`            | Hover / secondary accent           |
| `teal`                      | `#9CC4FF`            | Soft highlights                    |
| `text`                      | `#E8EEF8`            | Primary text                       |
| `text_muted`                | `#8AA0C0`            | Secondary text                     |
| `success / online`          | `#6EE7B7`            | Online status, success             |
| `outline`                   | `#57B4D2FF` (35%)    | Glass borders                      |
| `outline_subtle`            | `#29A0C4FF` (16%)    | Subtle dividers                    |
| `on_cyan`                   | `#041018`            | Text on primary buttons            |

### 2.2 Core Palette — Light Mode

| Token                        | Hex / Value          | Usage                              |
|-----------------------------|----------------------|------------------------------------|
| `bg_light`                  | `#F0F5FF`            | App background                     |
| `panel_light`               | `#FFFFFF`            | Cards, headers                     |
| `surface_highest_light`     | `#E8F0FF` / `#D6E6FF`| Elevated / selected                |
| `primary_light`             | `#2B7BFF`            | Primary actions                    |
| `text_light`                | `#0A1628`            | Primary text                       |
| `text_muted_light`          | `#5A6F8C`            | Secondary text                     |
| `outline_light`             | `#665B9DFF`          | Glass borders                      |

### 2.3 Glass Alpha Tokens

| Token                     | Value              | Usage                        |
|--------------------------|--------------------|------------------------------|
| `glass_10`               | 10% cyan           | Very subtle overlays         |
| `glass_20`               | 20% cyan           | Chips, light glass           |
| `glass_30`               | 30% cyan           | Status badges                |
| `glass_surface`          | ~80% panel         | Main glass panels            |
| `glass_surface_elevated` | ~90% elevated      | Floating elements            |

---

## 3. Typography

- **Primary font:** System / Inter / SF Pro (platform default)
- **Display / Logo:** Clean geometric sans
- **Weights:** Regular (400), Medium (500), Semibold (600)
- **Sizes (mobile):**
  - Display: 28–34 sp
  - Title: 20–22 sp
  - Body: 15–16 sp
  - Caption: 12–13 sp
  - Overline: 11 sp

---

## 4. Spacing & Radius

| Token          | Value     |
|----------------|-----------|
| `radius.sm`    | 8–10 dp   |
| `radius.md`    | 14–16 dp  |
| `radius.lg`    | 20–24 dp  |
| `radius.full`  | 999 dp    |
| Spacing scale  | 4 / 8 / 12 / 16 / 20 / 24 / 32 dp |

---

## 5. Components

### 5.1 Glass Card / Surface
- Background: `glass_surface` or `panel`
- Border: 1 dp `outline_subtle`
- Corner radius: 16 dp
- Optional subtle inner glow / elevation

### 5.2 Primary Button
- Background: `primary` (`#5B9DFF`)
- Text: `on_cyan`
- Radius: 14–16 dp
- Height: 48–52 dp

### 5.3 Message Bubbles
- **Outgoing:** Soft cyan-tinted glass + primary text
- **Incoming:** Dark glass panel + light text
- Radius: 16–18 dp (with tail)

### 5.4 Bottom Navigation
- Floating glass bar
- Active item: cyan icon + label
- Inactive: muted

### 5.5 Avatars
- Circular
- Online: thin cyan ring + green status dot

### 5.6 Unread Badge
- Background: `#5B9DFF`
- Text: white
- Pill shape

---

## 6. Elevation & Effects

- Prefer **glass + border** over heavy shadows
- Soft blur on headers and bottom sheets when supported
- Subtle cyan glow on focused / active elements
- No harsh drop shadows

---

## 7. Iconography

- **App icon:** Updated Ghost with liquid glass ring and soft cyan glow
- System icons: outlined style, 1.5–2 px stroke
- Accent icons use primary cyan

---

## 8. Accessibility

- Minimum contrast ratio 4.5:1 for body text
- Interactive targets ≥ 48 × 48 dp
- Support for system font scaling
- High-contrast mode should increase border opacity

---

## 9. Implementation Notes (Android)

- Tokens live in `res/values/colors.xml` and `core/ui/.../molly_colors.xml`
- Primary and surface colors overridden to Photon cyan/navy
- Custom drawables: `ghostweb_signal_*_background.xml` use glass alpha
- Material 3 `ColorScheme` consumes the updated molly tokens
- Splash screen uses `ghostweb_signal_bg`

---

**GhostWeb Enterprise · Liquid Glass Photon Design System v2.0**
